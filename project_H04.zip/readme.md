﻿# Graphical Programming and Visualized Debugging Platform
### COMP2012H project H04
#### CHEN Yijia   20582274
#### XIANG Tianqi 20583979

## Documentation ( totally 3 markdown files, in Documentation folder )
### readme.md
    similar to catalog
### project_discription.md
    introducing the project structure
### how_to_use.md
    describing the how to use the Analyzer
